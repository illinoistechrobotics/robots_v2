#!/bin/bash

javaw -Djava.ext.dirs=./lib -jar "robots.jar" &